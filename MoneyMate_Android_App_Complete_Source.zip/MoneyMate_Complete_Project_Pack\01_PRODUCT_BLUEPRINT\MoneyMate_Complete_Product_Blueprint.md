# MoneyMate — Product Blueprint (V5 consolidated)

## 1. Product purpose
MoneyMate is an India-first, personal money-management app designed to help a user answer:

**How much can I safely spend today after accounting for upcoming bills, EMIs, insurance premiums and savings commitments?**

It is not just a historical expense recorder. It should reduce routine data entry, keep imported data understandable and correctable, and translate cash-flow information into small useful decisions.

## 2. Product principles
1. **Setup before dashboard:** first launch collects enough information to create a useful starting plan. Never drop a new user into an empty dashboard.
2. **Automatic where consented:** connect supported financial data sources and/or use an eligible SMS import path. Keep a manual/CSV/statement fallback for unsupported sources.
3. **Never fake a connection:** show source status, last successful sync, date range imported and a clear reconnect/retry action.
4. **Automation must be auditable:** show the source, extracted details and category confidence; keep uncertain records in a review queue.
5. **Do not misstate money movement:** own-account transfers, cash withdrawals, reimbursements, refunds and credit-card repayments are not all ordinary income or expenses.
6. **Proactive but respectful:** provide a safe-to-spend number, upcoming commitments and an occasional useful review. Avoid guilt, noisy alerts and punitive language.
7. **Privacy-first:** collect only what is needed, explain permissions, process on-device when practical, and give the user control over source connections and deletion/export.
8. **Small first release:** no investment marketplace, credit score upsell, loan ads, social leaderboard or feature bloat.

## 3. First launch / onboarding flow

### Screen 1 — Welcome and identity
- Greeting: “Welcome to MoneyMate”.
- Ask preferred name (example in mockups: Swasthik); allow skip and edit later.
- Explain the promise in one line: “Know what is safe to spend today”.

### Screen 2 — Income and payday
Required to create the initial plan:
- Take-home monthly income (or multiple income sources / irregular income setting).
- Salary/payday date or pay-cycle choice.
- Whether the entered income is received already or expected.
- Optional additional income sources.

Do not assume every credit is income. Salary can be suggested only after the user confirms the source or recurring pattern.

### Screen 3 — Commitments and savings baseline
Ask only the minimum needed to start:
- Rent/fixed bills (optional).
- Loan EMIs (optional).
- Health, bike and car insurance premiums (optional; different commitment types).
- Existing savings target or monthly savings plan (optional).
- Start date / budget cycle.
Allow “Add later” for every optional item. Avoid asking for every category limit during onboarding.

### Screen 4 — Automatic data sources and permissions
Show options separately and honestly:
- Account Aggregator connection, where the app/operator is an eligible FIU and supported FIPs are available.
- SMS transaction tracking on Android only where the use case and required permission are approved and disclosed.
- CSV/statement import or manual entry fallback.
Explain exactly what data is accessed, for what purpose, where it is processed/stored, how to disconnect, and what happens if permission is declined.
Never silently request broad access before explaining the benefit and limitation.

### Screen 5 — Review and create plan
Summarise income, pay cycle, commitments, savings plan and selected import source. Let the user edit. Then create the budget and enter the personalized Home screen.

## 4. Main navigation / app overview
Five primary tabs:

1. **Home** — personalised greeting, safe-to-spend today, remaining flexible budget, time left in cycle, next commitment, savings progress, coach insight and quick add.
2. **Activity** — one unified timeline across supported sources, pending review, filters, transaction details, edit/correct, merchant notes and source badges.
3. **Budget** — monthly income, commitment reserves, category budgets, planned vs actual, daily allowance, trend/report views.
4. **Bills** — grouped section for loan EMIs, insurance policies and fixed recurring bills. EMI loans and insurance must remain visibly distinct types.
5. **Goals** — saving goals, target amount/date, contribution history and progress.

Profile/settings access should contain name and greeting preferences, income/pay cycle, category rules, source connections, permission/privacy controls, notification preferences, data backup/export, app lock and deletion controls.

A global floating **+** button is available across the main app. It opens a compact action sheet: Expense, Income, Transfer, Savings contribution, EMI, Insurance, Bill and Import/Review (where supported). It must not hide primary navigation or cover key content.

## 5. Home dashboard
Top-to-bottom priority:
1. Time-aware greeting: Good morning / Good afternoon / Good evening + user name.
2. Large “Safe to spend today” card.
3. “Remaining flexible budget” and days left in the budget period.
4. Upcoming EMI/insurance/bill card with due date and countdown.
5. Savings progress and goal contribution status.
6. Daily coach: celebrate positive progress, or give a calm actionable warning when spending pace is high.
7. Recent transactions and source sync status.

Do not make the Home screen a wall of charts. The first view should answer the most important questions in a few seconds.

## 6. Unified transaction automation

### Source connectors
- Account Aggregator: secure consent-based data sharing via an eligible FIU and AA partner; bank/financial-institution support varies.
- Android SMS: on-device financial SMS filtering and parsing only if the exact use case is eligible and the necessary policy/permission approvals are granted.
- Fallbacks: CSV/statement import, user-forwarded/pasted SMS text, or fast manual add.

### Transaction pipeline
1. Receive/import a record from a source.
2. Preserve source metadata and original transaction reference; do not retain unrelated message content.
3. Parse amount, currency, date/time, debit/credit, merchant/counterparty, masked account/card hint, UPI/reference ID, and source.
4. Normalize merchant text and payment instrument.
5. Match against known transaction patterns and user-corrected merchant rules.
6. Suggest type and category with a confidence score / explanation.
7. Run duplicate detection across SMS, AA and file imports.
8. Auto-add high-confidence ordinary expenses only if user has enabled this behaviour; keep uncertain classifications and all ambiguous credits in Review.
9. Recalculate budget, commitments and reports.
10. Allow undo, edit, recategorize, mark transfer/reimbursement, and report an import error.

### Review queue
- High confidence: can appear in Activity with an “Auto-categorized” label and easy correction.
- Medium confidence: suggest a category and ask for confirmation in a compact review card.
- Low confidence / ambiguous credit: do not silently classify; keep in Needs review.
- Learn only from corrections the user permits; make the rule visible and editable.

### Source health
Each connector shows Connected / Needs permission / Sync delayed / Disconnected / Unsupported, plus last successful sync and date range covered. Missing data must never look like zero spending.

## 7. Transaction model and accounting rules
Transaction types should include:
- Expense / purchase.
- Income (salary, freelance, interest, other confirmed income).
- Own-account transfer.
- Cash withdrawal / cash wallet transfer.
- Refund / reversal.
- Reimbursement receivable and reimbursement received.
- Credit-card purchase and credit-card bill settlement.
- Savings contribution / goal transfer.
- EMI payment and insurance premium payment, linked to a commitment.

Rules:
- Transfers between a user’s own accounts are not income or expense.
- ATM withdrawal moves money from bank to cash wallet; the withdrawal itself is not consumption. Cash purchases are logged separately.
- A card purchase is the expense. Paying the card bill is a settlement/transfer and must not count the purchase a second time.
- Money paid on behalf of a friend can be a receivable, not automatically a personal expense. Repayment clears that receivable, not income.
- Refunds reverse or reduce the original expense where they can be matched.
- A savings contribution moves money to savings / a goal; it reduces spendable cash but is not consumption spending.
- Ambiguous credits must not be silently counted as salary.

## 8. Budget engine — definitions
Use a configurable budget cycle (calendar month by default; payday-aligned cycle can be supported). All calculations use the same cycle.

**Available income:** confirmed income received in the cycle (with separately labelled forecast income if planned but not received).

**Reserved commitments:** unpaid EMI amounts + insurance premium reserves + fixed bills + other commitments reserved for this cycle. Reserve each obligation once.

**Planned savings:** user-defined amount allocated for savings goals/emergency fund.

**Flexible budget:** confirmed available income minus reserved commitments minus planned savings minus any other explicit reserves.

**Remaining flexible budget:** flexible budget minus eligible variable expenses recorded in the cycle.

**Daily safe-to-spend:** max(0, remaining flexible budget) divided by remaining days in the budget cycle (including today by default). If remaining flexible budget is negative, show “Over budget by ₹X”; do not show a positive daily allowance.

Important: reserving an EMI/insurance bill reduces spendable money once. When its payment is recorded, mark the reserve as paid/consumed; do not deduct the same amount again from flexible budget. Show cash/account balances separately from planned spendable budget.

### Insurance reserve logic
Health, bike and car insurance are policy records, not loans. Each can have premium amount, due/renewal date, recurrence, insurer, policy type, optional policy reference (masked), reminder schedule and payment history. For an annual premium, the user can set a monthly sinking-fund reserve (e.g. annual premium divided across the chosen saving months). Show the target reserve and any funding gap. Paying the annual premium marks the commitment paid; do not count it as a second everyday category expense if it was already reserved.

## 9. Categories
Default variable categories:
- Food / dining
- Grocery
- Shopping
- Fuel & transport
- Health & wellness
- Miscellaneous
- Custom categories (optional)

Fixed commitments such as rent/utilities, EMIs, insurance and subscriptions should be tracked separately from variable category limits. Users can rename, merge, split or add categories. Keep category set small at setup; allow flexibility later.

## 10. EMI and insurance section
Loan EMI fields: lender/name, principal or outstanding balance (optional), installment amount, due date, recurrence, start date, remaining installments, payment status/history and reminders.

Insurance fields: type (health / bike / car / other), insurer, premium, policy start/renewal date, frequency, coverage notes (optional), reminder dates, monthly reserve, payment status/history. Do not display insurance as a loan EMI, even though both appear in the Bills overview.

Bills overview shows total commitments due in cycle, but separates totals: loan EMIs, insurance premiums/reserves and other fixed bills.

## 11. Savings and goals
Each goal has name, target amount, current amount, optional target date, contribution plan, contribution history and progress. Suggested monthly contribution can be calculated from remaining amount and months to target. User can pause, edit or close a goal. Contributions reduce spendable cash but are not consumption expenses.

## 12. Daily money coach
Tone: supportive, plain, never shaming.
Examples:
- Positive: “You saved ₹2,000 today. Nice progress — keep your planned pace.”
- Neutral: “You are within today’s plan. You have ₹X left in your flexible budget.”
- Caution: “You are spending faster than planned. Consider keeping today’s optional spending under ₹X.”
- Recovery: “You had a high-spend day. Your plan is still editable; let’s rebalance the remaining days.”

Do not generate a congratulation from unverified or misclassified data. Show the reason: amount, comparison period and the transaction set used. Allow users to disable or tune coaching. Avoid frequent generic pings.

## 13. Reports
V1 reports:
- Planned vs actual by category.
- Daily spending trend.
- Cash flow (income, expense, transfers and savings shown distinctly).
- Upcoming commitments calendar.
- Month-on-month comparison.

Only show reports when data coverage is clear. Display last sync / incomplete source warning when a data feed is stale or partial.

## 14. Notifications
Only actionable notifications:
- EMI / insurance renewal reminders based on user schedule.
- One configurable budget warning near a category threshold.
- Optional weekly review with a useful decision.
No repeated alerts for every transaction; no shame language.

## 15. Privacy and security expectations
- Data minimisation and explicit, granular consent.
- No bank password/PIN collection or screen scraping.
- On-device SMS parsing where possible; process only recognised transaction alerts and discard irrelevant text.
- Mask account identifiers in UI.
- Encrypt sensitive locally stored data and use OS-secure key management in native build.
- App lock (PIN/biometric) optional.
- Clear source disconnect, local data deletion and export controls.
- Backup encrypted and opt-in; never imply a backup exists if not configured.
- Security/privacy policy and data-retention rules required before release.

## 16. V1 scope
Must build:
- First-launch onboarding and personalized profile.
- Income, pay cycle, commitments and savings baseline.
- Native transaction store and quick-add.
- Unified activity history and review queue.
- Budget engine with clear formulas.
- Loan EMI, health/bike/car insurance and fixed bill schedules.
- Goals and contributions.
- Actionable dashboard and reports.
- Source connection status and import abstraction.
- Export, app lock and privacy controls.

Integration gate: live Account Aggregator requires eligible FIU status / partner arrangements and FIP support. Live SMS inbox collection requires Android implementation, policy eligibility, disclosure, consent and Play approval if distributed through Google Play. If these are not ready, release with CSV/statement import and user-initiated SMS text import; do not pretend automation is active.

Not V1:
- Investment trading/marketplace, credit score upsells, loan offers, social features, complex net worth aggregator, AI chatbot, paid paywall for basic tracking.

## 17. Suggested implementation architecture
- Android: Kotlin + Jetpack Compose.
- Local persistence: Room database.
- Background work: WorkManager for supported scheduled sync/reminders.
- Secure secrets: Android Keystore; encrypt sensitive records / backups.
- Domain layer: transaction normalization, dedupe, classification, ledger rules, budget engine.
- Import adapters: AA partner/API adapter, SMS parser adapter (if approved), CSV/statement importer, manual entry.
- Notifications: local scheduled notification subsystem.
- Testing: unit tests for duplicate detection, transfers, reimbursements, card settlements, refunds, budget reserve lifecycle, date boundaries and time zones.

## 18. Acceptance criteria before release
1. A new user completes onboarding and arrives at a populated dashboard based on their answers.
2. Declining SMS/AA permissions does not block manual/CSV functionality.
3. A disconnected source is visibly marked and its old data is not represented as current.
4. Duplicate SMS/AA imports do not double count a transaction.
5. Own transfers, ATM cash withdrawals, reimbursements and credit-card repayments do not inflate spending/income.
6. Category corrections are easy and persist as user rules where consented.
7. EMI and insurance reserves are counted once and payment marking does not double deduct.
8. Insurance renewals can be forecast via monthly reserve.
9. Backdated edits correctly recalculate all affected periods.
10. Export and delete controls work and are tested.

## 19. Source notes
The product decisions above consolidate the user's stated requirements and supplied discussion/research about high manual-entry friction, broken sync, misclassification, financial-data fragmentation, privacy concerns, notification fatigue and reactive dashboards. The original supplied research text is preserved in `04_RESEARCH_REFERENCES`.

India-specific implementation references to verify during engineering:
- Ministry of Finance, Account Aggregator Framework: https://www.financialservices.gov.in/account-aggregator-framework
- RBI NBFC-AA Master Directions: https://systemhealth.rbi.org.in/Scripts/BS_ViewMasDirections.aspx_id%3D10598%281%29.html
- Google Play SMS/Call Log permissions policy: https://support.google.com/googleplay/android-developer/answer/10208820
- Google Play policy preview / updates: https://support.google.com/googleplay/android-developer/answer/17225965

These integrations are conditional. Product design does not itself establish regulatory eligibility or permission approval.
