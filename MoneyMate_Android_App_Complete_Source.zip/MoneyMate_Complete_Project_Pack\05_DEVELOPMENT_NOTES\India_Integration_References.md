# Current implementation references (checked 4 November 2026)

1. Government of India, Ministry of Finance — Account Aggregator Framework:
   https://www.financialservices.gov.in/account-aggregator-framework
   Describes AA as a consent-based financial data-sharing system; participation is voluntary for consumers; financial data is shared based on explicit consent. FIU eligibility/partner and institution coverage must be verified for the actual operator.

2. RBI — NBFC Account Aggregator Master Directions:
   https://systemhealth.rbi.org.in/Scripts/BS_ViewMasDirections.aspx_id%3D10598%281%29.html
   Contains explicit-consent, purpose and data-security provisions; confirm current consolidated directions before implementation.

3. Google Play — Use of SMS or Call Log permission groups:
   https://support.google.com/googleplay/android-developer/answer/10208820
   Lists SMS-based money management (budget tracking) as a potentially eligible use case subject to review and approval; permissions remain highly restricted and require declaration, prominent disclosure and consent.

4. Google Play — SMS/Call Log policy preview and additional compliance notes:
   https://support.google.com/googleplay/android-developer/answer/17225965
   Includes spyware/data minimisation and User Data Policy constraints. Recheck the policy and submission requirements at release time.

No statement in this package guarantees that MoneyMate qualifies for AA or SMS permissions. Eligibility and approvals depend on the actual business/legal structure, declared core functionality and platform review.
