# MoneyMate — Android APK Build Instructions

MoneyMate is an India-first personal money-management Android app built with Flutter and a native Kotlin platform layer.

---

## 📁 Project Location
The full source code is located at:
`c:\Users\Rushikesh\Downloads\Black world\MoneyMate\app`

---

## 🛠️ Prerequisites to Build the APK

To build the APK on your Windows machine, ensure you have:
1. **Flutter SDK** (v3.10.0 or later): [Download Flutter](https://docs.flutter.dev/get-started/install/windows)
2. **Android Studio** or Android Command Line Tools with Android SDK API 34
3. **Java Development Kit (JDK 17 or JDK 11)**

---

## 🚀 How to Build the APK

### Method 1: Using Command Line (Fastest)

1. Open PowerShell / Command Prompt and navigate to the project directory:
   ```powershell
   cd "c:\Users\Rushikesh\Downloads\Black world\MoneyMate\app"
   ```

2. Fetch Flutter dependencies:
   ```bash
   flutter pub get
   ```

3. Build the Release APK:
   ```bash
   flutter build apk --release
   ```

4. Once finished, your APK will be generated at:
   `app\build\app\outputs\flutter-apk\app-release.apk`

---

### Method 2: Using Android Studio

1. Open **Android Studio**.
2. Select **Open** and choose:
   `c:\Users\Rushikesh\Downloads\Black world\MoneyMate\app`
3. Wait for Flutter plugins and Gradle sync to finish.
4. Go to **Build** menu > **Flutter** > **Build APK**.
5. The notification at the bottom right will show you the link to the generated `.apk` file.

---

## 📱 Features Included in this Build (Per V5 Blueprint)

1. **Setup Before Dashboard (First Launch)**
   - 5-step onboarding flow (Identity, Income & Payday, Commitments, Data Sources, Plan Review).
2. **Daily Safe-To-Spend Calculation Engine**
   - Formula: `flexible_budget = confirmed_income - commitments - savings - reserves`
   - Formula: `daily_safe_to_spend = max(0, remaining_flexible_budget) / days_left`
3. **Bills & Commitments**
   - Loan EMIs and Insurance Policies (Health, Bike, Car) tracked as strictly distinct categories.
   - Insurance Sinking Fund (1/12th annual premium reserved monthly).
4. **Accounting Rules**
   - Own-account transfers, card settlements, cash withdrawals, and savings contributions do NOT distort variable spending.
5. **Activity & Review Queue**
   - Layered duplicate detection (Reference ID + Amount + Date window + Merchant).
   - Review cards for ambiguous records.
6. **Native Kotlin Layer**
   - `MainActivity.kt` & `SmsParserPlugin.kt` platform channels for on-device financial SMS processing.
