# MoneyMate — Calculation and Transaction Rules

## Daily allowance

Let:
- `confirmed_income` = received, user-confirmed income in the active cycle.
- `commitment_reserve` = unpaid EMI reserves + insurance reserves + fixed bills reserved for this cycle.
- `planned_savings` = savings the user has chosen to set aside.
- `other_reserves` = explicit additional planned commitments.
- `eligible_variable_spend` = ordinary expenses assigned to categories, excluding transfers, card settlements, reimbursements and savings transfers.

`flexible_budget = confirmed_income - commitment_reserve - planned_savings - other_reserves`

`remaining_flexible_budget = flexible_budget - eligible_variable_spend`

`days_left = number of calendar days remaining in the cycle, including today`

If remaining budget is positive:
`daily_safe_to_spend = remaining_flexible_budget / days_left`

If zero or negative: show zero safe-to-spend and clearly show budget exhausted / over budget. Never show a positive allowance when already overspent.

Projected income is separate. Do not include it in confirmed cash availability unless the user opts into a forecast view, and always label it Projected.

## Reserve lifecycle
1. Create a scheduled commitment for the cycle.
2. Reserve amount once in the plan.
3. When payment occurs, link the actual payment to that commitment and mark it paid.
4. Do not subtract it again from the flexible budget as an everyday expense.
5. Reconcile differences between expected and actual amounts.

## Insurance sinking fund
For annual premium `P` and user-selected saving horizon `N` months:
`monthly_insurance_reserve = P / N`

Show total planned reserve, amount already set aside, amount still needed and renewal due date. If the policy is due sooner than the planned horizon, show a funding shortfall instead of assuming the whole premium is available.

## Duplicate detection
Use a layered match: provider transaction/reference ID first; otherwise compare amount, direction, date/time window, normalized counterparty, masked account/card, and payment instrument. Keep possible matches for review when uncertain. Do not merge unrelated repeated small purchases solely because amounts are equal.

## Classification
- Debit from bank/UPI/card can be purchase, transfer, card settlement, cash withdrawal, EMI, insurance, fee or refund reversal.
- Credit can be salary, other income, refund, reimbursement, own-account transfer, loan disbursement or other. Do not infer income from direction alone.
- High-confidence recurring salary or known merchant patterns may be suggested; user-confirmed patterns can be reused.
- Medium/low confidence appears in review.

## Required edge cases to test
- Own savings transfer between linked accounts.
- One friend reimbursement after a shared dinner.
- Multiple small transactions to same merchant in one day.
- ATM cash withdrawal followed by cash purchases.
- Credit-card purchase and later credit-card bill payment.
- Partial refund and full reversal.
- EMI posted by bank and separately detected through SMS.
- Annual insurance premium with monthly reserve.
- Backdated transaction after a month has closed.
- Imported transaction date in a different timezone than device display.
